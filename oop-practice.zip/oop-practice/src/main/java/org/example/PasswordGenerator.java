package org.example;

@FunctionalInterface
public interface PasswordGenerator {
    String generatePassword();
}
